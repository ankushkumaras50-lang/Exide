// Exide Battery Wholesale & AET Official Partner - Cart & Multi-Step Checkout System
// Tailored for Nepal e-commerce, currency in NPR, eSewa, Khalti, Fonepay QR, COD & Scrap Battery Recycling Rebate

class CartSystem {
  constructor() {
    this.items = [];
    this.exchangeScrapActive = false;
    this.scrapBatteryAh = 0; // Customer inputted scrap battery capacity in Ah
    this.appliedCoupon = null;
    this.deliveryFee = 0; // Free inside Kathmandu valley & major Nepal cities
    this.vatRate = 0.13; // Nepal 13% VAT
    this.currentStep = 1;
    this.selectedPayment = 'esewa';
    this.lastOrder = null;

    this.init();
  }

  init() {
    this.loadCart();
    this.bindEvents();
    this.renderCartUI();
  }

  loadCart() {
    try {
      const stored = localStorage.getItem('bm_exide_cart');
      if (stored) {
        this.items = JSON.parse(stored);
      }
      const exchange = localStorage.getItem('bm_exide_exchange');
      if (exchange) {
        this.exchangeScrapActive = JSON.parse(exchange);
      }
      const scrapAh = localStorage.getItem('bm_exide_scrap_ah');
      if (scrapAh) {
        this.scrapBatteryAh = JSON.parse(scrapAh);
      }
    } catch (e) {
      console.error('Error loading cart', e);
      this.items = [];
    }
  }

  saveCart() {
    try {
      localStorage.setItem('bm_exide_cart', JSON.stringify(this.items));
      localStorage.setItem('bm_exide_exchange', JSON.stringify(this.exchangeScrapActive));
      localStorage.setItem('bm_exide_scrap_ah', JSON.stringify(this.scrapBatteryAh));
    } catch (e) {
      console.error('Error saving cart', e);
    }
  }

  addItem(productId, quantity = 1, buttonElement = null) {
    const product = window.productsCatalog ? window.productsCatalog.find(p => p.id === productId) : null;
    if (!product) {
      showToast('Product not found', 'error');
      return;
    }

    if (product.stock <= 0) {
      showToast('Sorry, this product is currently out of stock!', 'error');
      return;
    }

    // Trigger button animation if provided or from click event
    const btn = buttonElement || (window.event?.target?.closest('button'));
    if (btn) {
      animateAddToCartButton(btn);
    }

    const existingIndex = this.items.findIndex(item => item.id === productId);
    if (existingIndex > -1) {
      const newQty = this.items[existingIndex].quantity + quantity;
      if (newQty > product.stock) {
        showToast(`Only ${product.stock} units available in stock.`, 'warning');
        this.items[existingIndex].quantity = product.stock;
      } else {
        this.items[existingIndex].quantity = newQty;
        showToast(`Updated quantity: ${product.name}`, 'success');
      }
    } else {
      this.items.push({
        id: product.id,
        sku: product.sku,
        name: product.name,
        price: product.price,
        image: product.image,
        brand: product.brand,
        capacity: product.capacity,
        quantity: Math.min(quantity, product.stock)
      });
      showToast(`Added to cart: ${product.name}`, 'success');
    }

    this.saveCart();
    this.renderCartUI();
    this.openDrawer();
  }

  updateQuantity(productId, delta) {
    const item = this.items.find(i => i.id === productId);
    if (!item) return;

    const product = window.productsCatalog ? window.productsCatalog.find(p => p.id === productId) : null;
    const maxStock = product ? product.stock : 99;

    const newQty = item.quantity + delta;
    if (newQty <= 0) {
      this.removeItem(productId);
      return;
    }

    if (newQty > maxStock) {
      showToast(`Maximum ${maxStock} units currently available in stock!`, 'warning');
      return;
    }

    item.quantity = newQty;
    this.saveCart();
    this.renderCartUI();
  }

  removeItem(productId) {
    this.items = this.items.filter(i => i.id !== productId);
    this.saveCart();
    this.renderCartUI();
    showToast('Item removed from cart');
  }

  clearCart() {
    this.items = [];
    this.saveCart();
    this.renderCartUI();
  }

  toggleScrapExchange(active) {
    this.exchangeScrapActive = active;
    this.saveCart();
    this.renderCartUI();
  }

  setScrapAh(ah) {
    const parsed = parseInt(ah, 10);
    this.scrapBatteryAh = isNaN(parsed) || parsed < 0 ? 0 : parsed;
    this.saveCart();
    this.renderCartUI();
  }

  applyCoupon(code) {
    const clean = code.trim().toUpperCase();
    if (clean === 'EXIDE2026' || clean === 'DASHAIN') {
      this.appliedCoupon = { code: clean, discountPercent: 10 };
      showToast('Coupon applied! 10% instant discount', 'success');
    } else if (clean === 'POWERNEPAL') {
      this.appliedCoupon = { code: clean, discountPercent: 5 };
      showToast('Coupon applied! 5% instant discount', 'success');
    } else {
      showToast('Invalid promo coupon code', 'error');
      this.appliedCoupon = null;
    }
    this.renderCartUI();
  }

  getCalculations() {
    const rawSubtotal = this.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const totalItemsCount = this.items.reduce((sum, item) => sum + item.quantity, 0);

    // Old battery trade-in discount: Scrap capacity (Ah) * Scrap rate set in ERP settings
    const scrapRate = window.stockManager ? window.stockManager.getScrapRatePerAh() : 35;
    const scrapExchangeDeduction = (this.exchangeScrapActive && this.scrapBatteryAh > 0)
      ? Math.round(this.scrapBatteryAh * scrapRate)
      : 0;

    // Coupon discount
    const couponDiscount = this.appliedCoupon ? (rawSubtotal * (this.appliedCoupon.discountPercent / 100)) : 0;

    // Subtotal after deductions
    const adjustedSubtotal = Math.max(0, rawSubtotal - scrapExchangeDeduction - couponDiscount);

    // Delivery in Nepal (Free if > Rs. 5,000 or default)
    const finalDelivery = adjustedSubtotal > 5000 ? 0 : 350;

    // Grand total
    const grandTotal = Math.round(adjustedSubtotal + finalDelivery);

    // 13% Nepal VAT included in total
    const vatAmount = Math.round(grandTotal - (grandTotal / 1.13));

    return {
      rawSubtotal,
      totalItemsCount,
      scrapExchangeDeduction,
      scrapRate,
      scrapBatteryAh: this.scrapBatteryAh,
      couponDiscount,
      finalDelivery,
      grandTotal,
      vatAmount
    };
  }

  renderCartUI() {
    const totalCountEl = document.getElementById('header-cart-count');
    const drawerCounterEl = document.getElementById('drawer-items-count');
    const itemsContainer = document.getElementById('cart-items-container');
    const subtotalEl = document.getElementById('cart-subtotal-val');
    const grandTotalEl = document.getElementById('cart-grandtotal-val');
    const scrapRowEl = document.getElementById('cart-scrap-deduction-row');
    const scrapValEl = document.getElementById('cart-scrap-deduction-val');
    const deliveryFeeEl = document.getElementById('cart-delivery-val');
    const exchangeCheckbox = document.getElementById('exchange-scrap-checkbox');
    const scrapCalcContainer = document.getElementById('scrap-calc-container');
    const scrapAhInput = document.getElementById('scrap-ah-input');
    const scrapRateDisplay = document.getElementById('scrap-rate-display');
    const scrapFeedback = document.getElementById('scrap-discount-feedback');

    const calcs = this.getCalculations();

    if (totalCountEl) totalCountEl.textContent = calcs.totalItemsCount;
    if (drawerCounterEl) drawerCounterEl.textContent = `(${calcs.totalItemsCount})`;

    if (exchangeCheckbox) {
      exchangeCheckbox.checked = this.exchangeScrapActive;
    }

    if (scrapRateDisplay) {
      scrapRateDisplay.textContent = calcs.scrapRate;
    }

    // Toggle Scrap Calculator input container
    if (scrapCalcContainer) {
      scrapCalcContainer.style.display = this.exchangeScrapActive ? 'block' : 'none';
    }

    if (scrapAhInput && document.activeElement !== scrapAhInput) {
      scrapAhInput.value = this.scrapBatteryAh > 0 ? this.scrapBatteryAh : '';
    }

    // Show discount calculation feedback
    if (scrapFeedback) {
      if (this.exchangeScrapActive && this.scrapBatteryAh > 0) {
        scrapFeedback.style.display = 'block';
        scrapFeedback.innerHTML = `✓ ${this.scrapBatteryAh} Ah × NPR ${calcs.scrapRate}/Ah = <strong>-NPR ${calcs.scrapExchangeDeduction.toLocaleString()} Instant Scrap Discount Applied!</strong>`;
      } else if (this.exchangeScrapActive) {
        scrapFeedback.style.display = 'block';
        scrapFeedback.innerHTML = `<span style="color:#64748B;">💡 Please input your old battery capacity in Ah (e.g. 100, 150, 200) to view calculated discount.</span>`;
      } else {
        scrapFeedback.style.display = 'none';
      }
    }

    if (itemsContainer) {
      if (this.items.length === 0) {
        itemsContainer.innerHTML = `
          <div class="cart-empty-state">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="margin: 0 auto 1rem; color: #94A3B8;"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
            <h4 style="font-weight:700; color: #0F172A; margin-bottom: 0.25rem;">Your cart is empty</h4>
            <p style="font-size:0.85rem; color:#64748B;">Explore our range of Exide batteries, inverters & solar systems!</p>
          </div>
        `;
      } else {
        itemsContainer.innerHTML = this.items.map(item => `
          <div class="cart-item-row" data-id="${item.id}">
            <img src="${item.image}" alt="${item.name}" class="cart-item-img">
            <div>
              <div class="cart-item-title">${item.name}</div>
              <div class="cart-item-price">NPR ${item.price.toLocaleString()}</div>
              <div class="cart-item-qty">
                <button class="qty-btn" onclick="window.cartSystem.updateQuantity('${item.id}', -1)" aria-label="Decrease quantity">-</button>
                <span class="qty-display">${item.quantity}</span>
                <button class="qty-btn" onclick="window.cartSystem.updateQuantity('${item.id}', 1)" aria-label="Increase quantity">+</button>
              </div>
            </div>
            <button class="cart-item-remove-btn" onclick="window.cartSystem.removeItem('${item.id}')" title="Remove item" aria-label="Remove item">
              &times;
            </button>
          </div>
        `).join('');
      }
    }

    if (subtotalEl) subtotalEl.textContent = `NPR ${calcs.rawSubtotal.toLocaleString()}`;
    if (grandTotalEl) grandTotalEl.textContent = `NPR ${calcs.grandTotal.toLocaleString()}`;

    if (scrapRowEl && scrapValEl) {
      if (this.exchangeScrapActive && calcs.scrapExchangeDeduction > 0) {
        scrapRowEl.style.display = 'flex';
        scrapValEl.textContent = `- NPR ${calcs.scrapExchangeDeduction.toLocaleString()}`;
      } else {
        scrapRowEl.style.display = 'none';
      }
    }

    if (deliveryFeeEl) {
      deliveryFeeEl.textContent = calcs.finalDelivery === 0 ? 'FREE (Nepal Express)' : `NPR ${calcs.finalDelivery}`;
    }
  }

  openDrawer() {
    const overlay = document.getElementById('cart-drawer-overlay');
    if (overlay) overlay.classList.add('open');
  }

  closeDrawer() {
    const overlay = document.getElementById('cart-drawer-overlay');
    if (overlay) overlay.classList.remove('open');
  }

  openCheckoutModal() {
    if (this.items.length === 0) {
      showToast('Your cart is empty! Please add a product first.', 'warning');
      return;
    }
    this.closeDrawer();
    this.currentStep = 1;
    this.updateCheckoutStepUI();
    const modal = document.getElementById('checkout-modal-overlay');
    if (modal) modal.classList.add('open');
  }

  closeCheckoutModal() {
    const modal = document.getElementById('checkout-modal-overlay');
    if (modal) modal.classList.remove('open');
  }

  goToCheckoutStep(step) {
    if (step === 2) {
      // Validate Step 1 form fields
      const name = document.getElementById('chk-fullname')?.value.trim();
      const phone = document.getElementById('chk-phone')?.value.trim();
      const district = document.getElementById('chk-district')?.value;
      const address = document.getElementById('chk-address')?.value.trim();

      if (!name || !phone || !district || !address) {
        showToast('Please fill in your name, mobile number, district, and address.', 'warning');
        return;
      }

      // Check Nepal mobile format (98... or 97...)
      const cleanPhone = phone.replace(/\D/g, '');
      if (cleanPhone.length < 10) {
        showToast('Please enter a valid 10-digit Nepal mobile number (e.g. 98XXXXXXXX)', 'warning');
        return;
      }
    }

    this.currentStep = step;
    this.updateCheckoutStepUI();
  }

  updateCheckoutStepUI() {
    // Update step tabs
    const indicators = document.querySelectorAll('.checkout-step-indicator');
    indicators.forEach(ind => {
      const stepNum = parseInt(ind.dataset.step);
      ind.classList.remove('active', 'completed');
      if (stepNum === this.currentStep) ind.classList.add('active');
      if (stepNum < this.currentStep) ind.classList.add('completed');
    });

    // Toggle panels
    document.getElementById('checkout-step-1').style.display = this.currentStep === 1 ? 'block' : 'none';
    document.getElementById('checkout-step-2').style.display = this.currentStep === 2 ? 'block' : 'none';
    document.getElementById('checkout-step-3').style.display = this.currentStep === 3 ? 'block' : 'none';
    document.getElementById('checkout-step-4').style.display = this.currentStep === 4 ? 'block' : 'none';

    // Summary in Step 3
    if (this.currentStep === 3) {
      const calcs = this.getCalculations();
      const paySummaryEl = document.getElementById('checkout-payment-summary');
      if (paySummaryEl) {
        paySummaryEl.innerHTML = `
          <div style="background: var(--color-surface-bg); padding: 1rem; border-radius: var(--radius-md); border: 1.5px solid var(--color-border); margin-bottom: 1.25rem;">
            <div style="display:flex; justify-content:space-between; margin-bottom:0.25rem;">
              <span>Subtotal (${calcs.totalItemsCount} items):</span>
              <strong>NPR ${calcs.rawSubtotal.toLocaleString()}</strong>
            </div>
            ${this.exchangeScrapActive && calcs.scrapExchangeDeduction > 0 ? `
            <div style="display:flex; justify-content:space-between; color: var(--color-success); margin-bottom:0.25rem;">
              <span>Old Battery Trade-in (${calcs.scrapBatteryAh} Ah @ NPR ${calcs.scrapRate}/Ah):</span>
              <strong>- NPR ${calcs.scrapExchangeDeduction.toLocaleString()}</strong>
            </div>` : ''}
            <div style="display:flex; justify-content:space-between; margin-bottom:0.25rem;">
              <span>Delivery & Doorstep Fitting:</span>
              <strong style="color:var(--color-success);">${calcs.finalDelivery === 0 ? 'FREE' : 'NPR ' + calcs.finalDelivery}</strong>
            </div>
            <div style="display:flex; justify-content:space-between; font-size:1.1rem; font-weight:800; border-top:1px solid var(--color-border); padding-top:0.5rem; margin-top:0.5rem; color:var(--color-exide-red);">
              <span>Final Payable Amount:</span>
              <span>NPR ${calcs.grandTotal.toLocaleString()}</span>
            </div>
          </div>
        `;
      }
    }
  }

  selectPaymentMethod(method) {
    this.selectedPayment = method;
    document.querySelectorAll('.payment-method-card').forEach(card => {
      card.classList.toggle('selected', card.dataset.method === method);
    });

    // Toggle specific sub-panels
    document.getElementById('pay-details-esewa').style.display = method === 'esewa' ? 'block' : 'none';
    document.getElementById('pay-details-khalti').style.display = method === 'khalti' ? 'block' : 'none';
    document.getElementById('pay-details-fonepay').style.display = method === 'fonepay' ? 'block' : 'none';
    document.getElementById('pay-details-bank').style.display = method === 'bank' ? 'block' : 'none';
    document.getElementById('pay-details-cod').style.display = method === 'cod' ? 'block' : 'none';
  }

  processFinalOrder() {
    const calcs = this.getCalculations();
    const customer = {
      fullName: document.getElementById('chk-fullname')?.value.trim() || 'Valued Customer',
      phone: document.getElementById('chk-phone')?.value.trim() || '+9779705997260',
      email: document.getElementById('chk-email')?.value.trim() || 'customer@example.com',
      province: document.getElementById('chk-province')?.value || 'Bagmati',
      district: document.getElementById('chk-district')?.value || 'Kathmandu',
      city: document.getElementById('chk-city')?.value.trim() || 'Kathmandu',
      ward: document.getElementById('chk-ward')?.value.trim() || '10',
      address: document.getElementById('chk-address')?.value.trim() || 'Bijulibazar, Anamnagar, Kathmandu',
      landmark: document.getElementById('chk-landmark')?.value.trim() || '',
      notes: document.getElementById('chk-notes')?.value.trim() || '',
      panNumber: document.getElementById('chk-buyer-pan')?.value.trim() || 'N/A'
    };

    const deliveryOption = document.querySelector('input[name="delivery-type"]:checked')?.value || 'Express Doorstep Delivery';
    const fittingService = document.getElementById('chk-fitting-service')?.checked ? 'Professional Fitting Included (Free)' : 'Standard Delivery Only';

    const orderId = 'EX-NP-' + Math.floor(100000 + Math.random() * 900000);
    const invoiceNumber = 'INV-2026-' + Math.floor(1000 + Math.random() * 9000);
    const orderDate = new Date().toLocaleString('en-US', { timeZone: 'Asia/Kathmandu' });

    const orderRecord = {
      orderId,
      invoiceNumber,
      orderDate,
      customer,
      items: [...this.items],
      calculations: calcs,
      exchangeScrap: this.exchangeScrapActive,
      scrapBatteryAh: this.scrapBatteryAh,
      scrapRateUsed: calcs.scrapRate,
      deliveryOption,
      fittingService,
      paymentMethod: this.selectedPayment.toUpperCase(),
      paymentStatus: this.selectedPayment === 'cod' ? 'Pending (Pay on Delivery)' : 'Paid / Verified',
      status: 'Pending',
      trackingHistory: [
        { step: 'Order Placed', time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }), note: 'Order placed by customer via web storefront' }
      ]
    };

    this.lastOrder = orderRecord;

    // Deduct stock in Stock Manager
    if (window.stockManager) {
      orderRecord.items.forEach(item => {
        window.stockManager.deductStockForOrder(item.id, item.quantity, orderId);
      });

      // Add to ERP orders
      window.stockManager.orders.unshift(orderRecord);
      window.stockManager.saveOrders();
      window.stockManager.renderAdminUI();
    }

    // Clear cart
    this.clearCart();

    // Render invoice confirmation step
    this.renderInvoiceUI(orderRecord);
    this.goToCheckoutStep(4);
    showToast(`Order #${orderId} confirmed successfully!`, 'success');
  }

  renderInvoiceUI(order) {
    const container = document.getElementById('checkout-step-4');
    if (!container) return;

    const hqLocation = window.stockManager ? window.stockManager.settings.headOffice : 'Kathmandu - Bijulibazar (Head office) - Bijulibazar, Anamnagar (near to BhatBhateni)';
    const storePhone = window.stockManager ? window.stockManager.settings.storePhone : '+9779705997260';
    const vatNum = window.stockManager ? window.stockManager.settings.vatNumber : '609823412';

    container.innerHTML = `
      <div class="invoice-card" id="printable-invoice">
        <div class="invoice-header-row">
          <div>
            <img src="assets/logo.png" alt="Exide Battery Wholesale" class="invoice-logo-img">
            <h3 style="font-size:1.1rem; font-weight:800; color:var(--color-exide-blue);">EXIDE BATTERY WHOLESALE</h3>
            <p style="font-size:0.8rem; color:#64748B;">AET Official Partner • The Power House</p>
            <p style="font-size:0.8rem; color:#64748B;">${hqLocation}</p>
            <p style="font-size:0.8rem; font-weight:700; color:#0F172A;">IRD VAT/PAN Registration: ${vatNum}</p>
            <p style="font-size:0.8rem; color:#64748B;">Hotline: ${storePhone} | batterymartbtl@gmail.com</p>
          </div>
          <div style="text-align:right;">
            <div style="display:inline-block; background:var(--color-exide-red); color:#fff; font-weight:800; padding:0.25rem 0.75rem; border-radius:4px; font-size:0.8rem; text-transform:uppercase;">
              TAX INVOICE / भ्याट बिल
            </div>
            <h2 style="font-size:1.25rem; font-weight:800; color:#0F172A; margin-top:0.5rem;">Order #${order.orderId}</h2>
            <p style="font-size:0.85rem; color:#64748B;">Invoice: <strong>${order.invoiceNumber}</strong></p>
            <p style="font-size:0.8rem; color:#64748B;">Date: ${order.orderDate}</p>
            <p style="font-size:0.85rem; font-weight:700; color:var(--color-success); margin-top:0.25rem;">Payment: ${order.paymentStatus}</p>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:1.5rem; background:#F8FAFC; padding:1.25rem; border-radius:8px; margin-bottom:1.5rem; border:1px solid #E2E8F0;">
          <div>
            <h4 style="font-size:0.85rem; text-transform:uppercase; color:#64748B; font-weight:700; margin-bottom:0.25rem;">Bill To / Customer</h4>
            <div style="font-size:0.95rem; font-weight:800; color:#0F172A;">${order.customer.fullName}</div>
            <div style="font-size:0.85rem; color:#334155;">📞 ${order.customer.phone}</div>
            <div style="font-size:0.85rem; color:#334155;">✉️ ${order.customer.email}</div>
            <div style="font-size:0.85rem; color:#64748B;">Buyer PAN: <strong>${order.customer.panNumber}</strong></div>
          </div>
          <div>
            <h4 style="font-size:0.85rem; text-transform:uppercase; color:#64748B; font-weight:700; margin-bottom:0.25rem;">Delivery Destination</h4>
            <div style="font-size:0.9rem; font-weight:700; color:#0F172A;">${order.customer.address}, Ward ${order.customer.ward}</div>
            <div style="font-size:0.85rem; color:#334155;">${order.customer.city}, ${order.customer.district}</div>
            <div style="font-size:0.85rem; color:#64748B;">${order.customer.landmark ? 'Landmark: ' + order.customer.landmark : ''}</div>
            <div style="font-size:0.85rem; font-weight:600; color:var(--color-exide-blue); margin-top:0.25rem;">📦 ${order.deliveryOption} (${order.fittingService})</div>
          </div>
        </div>

        <table class="invoice-table">
          <thead>
            <tr>
              <th>SN</th>
              <th>Product Description & Capacity</th>
              <th>SKU</th>
              <th style="text-align:center;">Qty</th>
              <th style="text-align:right;">Rate (NPR)</th>
              <th style="text-align:right;">Amount (NPR)</th>
            </tr>
          </thead>
          <tbody>
            ${order.items.map((item, idx) => `
              <tr>
                <td>${idx + 1}</td>
                <td>
                  <strong>${item.name}</strong><br>
                  <small style="color:#64748B;">Capacity: ${item.capacity || 'Standard'} | Warranty Card Attached</small>
                </td>
                <td><code style="background:#F1F5F9; padding:2px 6px; border-radius:4px;">${item.sku}</code></td>
                <td style="text-align:center; font-weight:700;">${item.quantity}</td>
                <td style="text-align:right;">${item.price.toLocaleString()}</td>
                <td style="text-align:right; font-weight:700;">${(item.price * item.quantity).toLocaleString()}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>

        <div style="display:flex; justify-content:flex-end;">
          <div style="width:340px; display:flex; flex-direction:column; gap:0.35rem; font-size:0.9rem;">
            <div style="display:flex; justify-content:space-between;">
              <span style="color:#64748B;">Subtotal Amount:</span>
              <strong>NPR ${order.calculations.rawSubtotal.toLocaleString()}</strong>
            </div>
            ${order.exchangeScrap && order.calculations.scrapExchangeDeduction > 0 ? `
            <div style="display:flex; justify-content:space-between; color:var(--color-success);">
              <span>Scrap Battery Trade-in (${order.scrapBatteryAh || order.calculations.scrapBatteryAh} Ah @ NPR ${order.scrapRateUsed || order.calculations.scrapRate}/Ah):</span>
              <strong>- NPR ${order.calculations.scrapExchangeDeduction.toLocaleString()}</strong>
            </div>` : ''}
            <div style="display:flex; justify-content:space-between;">
              <span style="color:#64748B;">Delivery & Fitting:</span>
              <strong>${order.calculations.finalDelivery === 0 ? 'FREE' : 'NPR ' + order.calculations.finalDelivery}</strong>
            </div>
            <div style="display:flex; justify-content:space-between; border-top:1px solid #E2E8F0; padding-top:0.35rem; color:#64748B; font-size:0.8rem;">
              <span>13% VAT Tax (Included):</span>
              <span>NPR ${order.calculations.vatAmount.toLocaleString()}</span>
            </div>
            <div style="display:flex; justify-content:space-between; font-size:1.25rem; font-weight:800; border-top:2px solid var(--color-exide-red); padding-top:0.5rem; color:var(--color-exide-red);">
              <span>Grand Total:</span>
              <span>NPR ${order.calculations.grandTotal.toLocaleString()}</span>
            </div>
          </div>
        </div>

        <div style="margin-top:2rem; padding-top:1rem; border-top:1px dashed #CBD5E1; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1rem;">
          <div style="font-size:0.8rem; color:#64748B; max-width:480px;">
            <p><strong>Terms:</strong> 100% Genuine guaranteed with stamped warranty card. For claims or doorstep battery replacement service across Nepal, present this invoice.</p>
          </div>
          <div style="display:flex; gap:0.75rem;">
            <button class="btn-primary-red btn-print-invoice" onclick="window.printTaxInvoice(window.cartSystem?.lastOrder || null)" style="padding:0.6rem 1.25rem; font-size:0.85rem;">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect width="12" height="8" x="6" y="14"/></svg>
              Print Tax Bill
            </button>
            <a href="https://wa.me/9779705997260?text=Hi%2C%20I%20have%20placed%20Order%20%23${order.orderId}%20for%20NPR%20${order.calculations.grandTotal}%20at%20Battery%20Mart." target="_blank" class="btn-whatsapp" style="padding:0.6rem 1.25rem; font-size:0.85rem;">
              WhatsApp Notification
            </a>
            <button class="btn-outline-white" onclick="window.cartSystem.closeCheckoutModal()" style="border-color:#CBD5E1; color:#0F172A; padding:0.6rem 1.25rem; font-size:0.85rem;">
              Done
            </button>
          </div>
        </div>
      </div>
    `;
  }

  bindEvents() {
    // Province dropdown changes district
    document.addEventListener('change', (e) => {
      if (e.target && e.target.id === 'chk-province') {
        const provId = e.target.value;
        const districtSelect = document.getElementById('chk-district');
        if (districtSelect && window.NEPAL_LOCATIONS) {
          const prov = window.NEPAL_LOCATIONS.provinces.find(p => p.id === provId);
          if (prov) {
            districtSelect.innerHTML = prov.districts.map(d => `<option value="${d}">${d}</option>`).join('');
          }
        }
      }
    });
  }
}

// Button animation on Add to Cart
function animateAddToCartButton(btn) {
  if (!btn) return;
  btn.classList.add('btn-added-animate');
  const originalHtml = btn.innerHTML;
  btn.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
    <span>Added!</span>
  `;
  setTimeout(() => {
    btn.innerHTML = originalHtml;
    btn.classList.remove('btn-added-animate');
  }, 1200);

  // Pulse cart counter in header
  const headerCount = document.getElementById('header-cart-count');
  if (headerCount) {
    headerCount.classList.remove('pulse-bounce');
    void headerCount.offsetWidth; // trigger reflow
    headerCount.classList.add('pulse-bounce');
  }
}

// Global Toast Notifications
function showToast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast-message ${type === 'success' ? 'success' : ''}`;
  toast.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;">
      ${type === 'success' ? '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>' : '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>'}
    </svg>
    <span>${message}</span>
  `;

  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// Convert amount to words for Nepal Tax Bill
function numberToWordsNepal(num) {
  const a = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  
  if (!num || num === 0) return 'Zero';
  function convert(n) {
    if (n < 20) return a[n];
    if (n < 100) return b[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + a[n % 10] : '');
    if (n < 1000) return a[Math.floor(n / 100)] + ' Hundred' + (n % 100 !== 0 ? ' and ' + convert(n % 100) : '');
    if (n < 100000) return convert(Math.floor(n / 1000)) + ' Thousand' + (n % 1000 !== 0 ? ' ' + convert(n % 1000) : '');
    if (n < 10000000) return convert(Math.floor(n / 100000)) + ' Lakh' + (n % 100000 !== 0 ? ' ' + convert(n % 100000) : '');
    return convert(Math.floor(n / 10000000)) + ' Crore' + (n % 10000000 !== 0 ? ' ' + convert(n % 10000000) : '');
  }
  return 'Nepalese Rupees ' + convert(Math.round(num)) + ' Only';
}

// Global Official Nepal Tax Invoice Printer (A4 Format)
function printTaxInvoice(order) {
  const targetOrder = order || window.cartSystem?.lastOrder || (window.stockManager?.orders?.[0]);
  if (!targetOrder) {
    showToast('No active order record found to print.', 'warning');
    return;
  }

  const hqLocation = window.stockManager ? window.stockManager.settings.headOffice : 'Kathmandu - Bijulibazar (Head office) - Bijulibazar, Anamnagar (near to BhatBhateni)';
  const storePhone = window.stockManager ? window.stockManager.settings.storePhone : '+9779705997260';
  const vatNum = window.stockManager ? window.stockManager.settings.vatNumber : '609823412';
  
  const calcs = targetOrder.calculations || {
    rawSubtotal: (targetOrder.items || []).reduce((s, i) => s + (i.price * i.quantity), 0),
    scrapExchangeDeduction: targetOrder.exchangeScrap ? ((targetOrder.scrapBatteryAh || 0) * (targetOrder.scrapRateUsed || 35)) : 0,
    couponDiscount: 0,
    finalDelivery: 0,
    grandTotal: 0,
    vatAmount: 0
  };

  const grandTotal = calcs.grandTotal || Math.round(calcs.rawSubtotal - (calcs.scrapExchangeDeduction || 0) + (calcs.finalDelivery || 0));
  const vatAmount = calcs.vatAmount || Math.round(grandTotal - (grandTotal / 1.13));
  const wordsText = numberToWordsNepal(grandTotal);

  let portal = document.getElementById('printable-bill-portal');
  if (!portal) {
    portal = document.createElement('div');
    portal.id = 'printable-bill-portal';
    portal.className = 'printable-bill-portal';
    document.body.appendChild(portal);
  }

  portal.innerHTML = `
    <div class="print-invoice-doc">
      <!-- Header Grid -->
      <div class="print-header-grid">
        <div>
          <div style="display:flex; align-items:center; gap:8px; margin-bottom:4px;">
            <img src="assets/logo.png" alt="Exide Battery Wholesale" style="height:36px; object-fit:contain;">
            <div>
              <h1 class="print-company-name">EXIDE BATTERY WHOLESALE</h1>
              <p class="print-company-sub">AET Official Partner • The Power House</p>
            </div>
          </div>
          <p class="print-company-sub">${hqLocation}</p>
          <p class="print-company-pan">IRD VAT/PAN Registration: <strong>${vatNum}</strong></p>
          <p class="print-company-sub">Hotline: ${storePhone} | batterymartbtl@gmail.com</p>
        </div>
        <div class="print-meta-right">
          <span class="print-title-badge">TAX INVOICE / भ्याट बिल</span>
          <div style="font-size:12pt; font-weight:800; color:#0F172A; margin-top:4px;">Order #${targetOrder.orderId}</div>
          <div style="font-size:9pt; color:#475569;">Invoice: <strong>${targetOrder.invoiceNumber || 'INV-2026-6456'}</strong></div>
          <div style="font-size:8.5pt; color:#475569;">Date: ${targetOrder.orderDate}</div>
          <div style="font-size:8.5pt; font-weight:700; color:#15803D; margin-top:2px;">
            Payment: ${targetOrder.paymentStatus} (${targetOrder.paymentMethod || 'COD'})
          </div>
        </div>
      </div>

      <!-- Customer & Destination Grid -->
      <div class="print-two-col">
        <div>
          <div class="print-col-title">Bill To / Buyer Information</div>
          <div class="print-col-text">
            <strong>${targetOrder.customer?.fullName || 'Valued Customer'}</strong><br>
            📞 Mobile: ${targetOrder.customer?.phone || 'N/A'}<br>
            ✉️ Email: ${targetOrder.customer?.email || 'N/A'}<br>
            Buyer PAN/VAT: <strong>${targetOrder.customer?.panNumber || 'Unregistered Retail Consumer'}</strong>
          </div>
        </div>
        <div>
          <div class="print-col-title">Delivery Destination & Installation</div>
          <div class="print-col-text">
            <strong>${targetOrder.customer?.address || ''}, Ward ${targetOrder.customer?.ward || '01'}</strong><br>
            ${targetOrder.customer?.city || ''}, ${targetOrder.customer?.district || ''} (${targetOrder.customer?.province || ''})<br>
            ${targetOrder.customer?.landmark ? 'Landmark: ' + targetOrder.customer.landmark + '<br>' : ''}
            📦 ${targetOrder.deliveryOption || 'Express Doorstep Delivery'} (${targetOrder.fittingService || 'Free Fitting Included'})
          </div>
        </div>
      </div>

      <!-- Itemized Products Table -->
      <table class="print-table">
        <thead>
          <tr>
            <th style="width:36px; text-align:center;">SN</th>
            <th>Product Description & Capacity</th>
            <th style="width:115px;">SKU</th>
            <th style="width:48px; text-align:center;">Qty</th>
            <th style="width:95px; text-align:right;">Rate (NPR)</th>
            <th style="width:105px; text-align:right;">Amount (NPR)</th>
          </tr>
        </thead>
        <tbody>
          ${(targetOrder.items || []).map((item, idx) => `
            <tr>
              <td style="text-align:center; font-weight:700;">${idx + 1}</td>
              <td>
                <strong>${item.name}</strong><br>
                <small style="color:#475569;">Capacity: ${item.capacity || 'Standard'} | Official Stamped Warranty Attached</small>
              </td>
              <td><code style="font-family:monospace; font-weight:700; color:#003080;">${item.sku}</code></td>
              <td style="text-align:center; font-weight:800;">${item.quantity}</td>
              <td style="text-align:right;">${item.price.toLocaleString()}</td>
              <td style="text-align:right; font-weight:700;">${(item.price * item.quantity).toLocaleString()}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>

      <!-- Calculations & Totals -->
      <div class="print-totals-box">
        <div class="print-totals-table">
          <div class="print-totals-row">
            <span style="color:#475569;">Subtotal Amount:</span>
            <strong>NPR ${calcs.rawSubtotal.toLocaleString()}</strong>
          </div>
          ${targetOrder.exchangeScrap && calcs.scrapExchangeDeduction > 0 ? `
            <div class="print-totals-row" style="color:#15803D;">
              <span>Scrap Trade-in (${targetOrder.scrapBatteryAh || calcs.scrapBatteryAh} Ah @ NPR ${targetOrder.scrapRateUsed || calcs.scrapRate}/Ah):</span>
              <strong>- NPR ${calcs.scrapExchangeDeduction.toLocaleString()}</strong>
            </div>
          ` : ''}
          ${calcs.couponDiscount > 0 ? `
            <div class="print-totals-row" style="color:#15803D;">
              <span>Promo Discount:</span>
              <strong>- NPR ${calcs.couponDiscount.toLocaleString()}</strong>
            </div>
          ` : ''}
          <div class="print-totals-row">
            <span style="color:#475569;">Doorstep Delivery & Fitting:</span>
            <strong>${calcs.finalDelivery === 0 ? 'FREE (NPR 0)' : 'NPR ' + calcs.finalDelivery.toLocaleString()}</strong>
          </div>
          <div class="print-totals-row" style="border-top:1px dashed #CBD5E1; padding-top:2px; font-size:8pt; color:#475569;">
            <span>13% Nepal VAT Tax (Included):</span>
            <span>NPR ${vatAmount.toLocaleString()}</span>
          </div>
          <div class="print-totals-row grand">
            <span>Grand Total:</span>
            <span>NPR ${grandTotal.toLocaleString()}</span>
          </div>
        </div>
      </div>

      <!-- In Words -->
      <div class="print-words-box">
        <strong>In Words:</strong> ${wordsText}
      </div>

      <!-- Terms & Conditions -->
      <div style="font-size:7.5pt; color:#64748B; margin-top:10px; border-top:1px dashed #CBD5E1; padding-top:6px;">
        <strong>Terms & Conditions:</strong>
        1. 100% Genuine guaranteed with manufacturer warranty card.
        2. In case of replacement claim, please present this tax invoice or registered mobile number at any Exide Battery Wholesale / AET outlet.
        3. Electrical damage due to external short-circuit is governed by standard manufacturer warranty policy.
      </div>

      <!-- Signatures Row -->
      <div class="print-signatures-row">
        <div class="print-sig-box">
          Customer Receiver Signature
        </div>
        <div>
          <div class="print-seal-stamp">
            EXIDE BATTERY<br>WHOLESALE<br>★ AET VERIFIED ★
          </div>
        </div>
        <div class="print-sig-box">
          Authorized Signatory<br>
          <small style="color:#64748B;">For Exide Battery Wholesale / AET Official Partner</small>
        </div>
      </div>
    </div>
  `;

  document.body.classList.add('printing-bill');

  setTimeout(() => {
    window.print();
  }, 100);

  const cleanup = () => {
    document.body.classList.remove('printing-bill');
    window.removeEventListener('afterprint', cleanup);
  };
  window.addEventListener('afterprint', cleanup);
  setTimeout(cleanup, 4000);
}

// ==========================================================================
// COMMERCIAL ORDERS: PARCEL & PACKAGING SHIPPING LABEL PRINTING
// ==========================================================================
function printShippingParcelLabel(order) {
  let targetOrder = order;
  if (typeof order === 'string') {
    targetOrder = window.stockManager ? window.stockManager.orders.find(o => o.orderId === order) : null;
  }
  if (!targetOrder) {
    if (window.showToast) window.showToast('Order details not found for parcel printing', 'warning');
    return;
  }

  const settings = window.stockManager?.settings || {
    storePhone: '+9779705997260',
    headOffice: 'Bijulibazar, Anamnagar (near BhatBhateni), Kathmandu, Nepal',
    vatNumber: '601928374'
  };

  let portal = document.getElementById('printable-bill-portal');
  if (!portal) {
    portal = document.createElement('div');
    portal.id = 'printable-bill-portal';
    portal.className = 'printable-bill-portal';
    document.body.appendChild(portal);
  }

  const isCOD = targetOrder.paymentMethod?.toLowerCase().includes('cash') || !targetOrder.paymentStatus?.toLowerCase().includes('paid');
  const codAmount = targetOrder.calculations?.grandTotal || 0;

  const itemsList = (targetOrder.items || []).map(i => `
    <div style="display:flex; justify-content:space-between; font-size:8.5pt; border-bottom:1px dashed #CBD5E1; padding:3px 0;">
      <span><strong>${i.quantity}x</strong> ${i.name} (<code style="font-weight:700;">${i.sku}</code>)</span>
      <span>${i.capacity || ''}</span>
    </div>
  `).join('');

  portal.innerHTML = `
    <div class="print-parcel-label">
      <!-- Label Header -->
      <div class="parcel-label-header">
        <div style="display:flex; align-items:center; gap:8px;">
          <img src="assets/logo.png" alt="Exide Battery Wholesale" style="height:38px; object-fit:contain;">
          <div>
            <div style="font-size:12pt; font-weight:900; line-height:1; color:#0047BA;">EXIDE BATTERY WHOLESALE</div>
            <div style="font-size:7.5pt; font-weight:700; color:#E21B23; letter-spacing:0.5px;">AET OFFICIAL PARTNER • COMMERCIAL LOGISTICS HUB</div>
          </div>
        </div>
        <div class="parcel-badge-priority">
          PRIORITY DISPATCH
        </div>
      </div>

      <!-- Barcode & Order Identifier -->
      <div class="parcel-barcode-row">
        <div class="parcel-barcode-mock">
          |||||| | |||||||| |||| ||||||| ||||| |||||||| |||| |||||
        </div>
        <div style="font-family:monospace; font-size:11pt; font-weight:800; letter-spacing:1.5px; color:#0F172A;">
          ORDER: #${targetOrder.orderId}
        </div>
      </div>

      <!-- Sender & Destination Grid -->
      <div class="parcel-address-grid">
        <!-- FROM SENDER -->
        <div class="parcel-sender-box">
          <div class="parcel-box-tag">SENDER (प्रेषक)</div>
          <div class="parcel-sender-name">EXIDE BATTERY WHOLESALE</div>
          <div class="parcel-sender-text">
            Central Logistics Depot<br>
            ${settings.headOffice}<br>
            Hotline: <strong>${settings.storePhone}</strong><br>
            PAN/VAT: <strong>${settings.vatNumber}</strong>
          </div>
        </div>

        <!-- TO RECIPIENT -->
        <div class="parcel-recipient-box">
          <div class="parcel-box-tag red">SHIP TO / DESTINATION (प्रापक)</div>
          <div class="parcel-recipient-name">${targetOrder.customer?.fullName || 'Valued Customer'}</div>
          <div class="parcel-recipient-phone">
            📞 Mobile: <strong>${targetOrder.customer?.phone || 'N/A'}</strong>
          </div>
          <div class="parcel-recipient-address">
            <strong>${targetOrder.customer?.address || ''}, Ward ${targetOrder.customer?.ward || '01'}</strong><br>
            ${targetOrder.customer?.landmark ? `Landmark: <u>${targetOrder.customer.landmark}</u><br>` : ''}
            <strong>${targetOrder.customer?.city || ''}, ${targetOrder.customer?.district || ''}</strong> (${targetOrder.customer?.province || 'Nepal'})
          </div>
        </div>
      </div>

      <!-- Parcel Content Summary -->
      <div class="parcel-items-box">
        <div style="font-size:8pt; font-weight:800; text-transform:uppercase; color:#475569; margin-bottom:4px; display:flex; justify-content:space-between;">
          <span>📦 Package Contents (${(targetOrder.items || []).length} SKU lines)</span>
          <span>Fitting: ${targetOrder.fittingService || 'Free Doorstep'}</span>
        </div>
        ${itemsList}
      </div>

      <!-- COD / Payment Collection Box -->
      <div class="parcel-cod-box ${isCOD ? 'is-cod' : 'is-prepaid'}">
        <div style="font-size:9pt; font-weight:800;">
          ${isCOD ? '⚠️ CASH ON DELIVERY (COD) - COLLECT FROM CUSTOMER' : '✅ PREPAID ORDER - DO NOT COLLECT ANY CASH'}
        </div>
        <div style="font-size:16pt; font-weight:900; margin-top:2px;">
          ${isCOD ? `COLLECT: NPR ${codAmount.toLocaleString()}` : `PAID IN FULL (${targetOrder.paymentMethod || 'Online'})`}
        </div>
      </div>

      <!-- Handling & Battery Safety Warnings -->
      <div class="parcel-handling-row">
        <div class="parcel-handling-item">
          <span style="font-size:16pt;">⚡</span>
          <div>
            <strong>HEAVY POWER CARGO</strong>
            <small>Lead-Acid / LiFePO4</small>
          </div>
        </div>
        <div class="parcel-handling-item">
          <span style="font-size:16pt;">⬆️</span>
          <div>
            <strong>THIS WAY UP</strong>
            <small>Keep Upright Always</small>
          </div>
        </div>
        <div class="parcel-handling-item">
          <span style="font-size:16pt;">🛡️</span>
          <div>
            <strong>FRAGILE TERMINALS</strong>
            <small>Handle With Care</small>
          </div>
        </div>
        <div class="parcel-stamp-box">
          AET OFFICIAL<br>LOGISTICS<br>★ DISPATCHED ★
        </div>
      </div>

      <div class="parcel-footer-note">
        For delivery issues, call Central Logistics Helpline: ${settings.storePhone} | Inspect seals upon arrival.
      </div>
    </div>
  `;

  document.body.classList.add('printing-bill');
  setTimeout(() => {
    window.print();
    setTimeout(() => {
      document.body.classList.remove('printing-bill');
      if (portal) portal.innerHTML = '';
    }, 1000);
  }, 250);
}

window.printTaxInvoice = printTaxInvoice;
window.printShippingParcelLabel = printShippingParcelLabel;
window.numberToWordsNepal = numberToWordsNepal;

