// Exide Battery Wholesale & AET Official Partner - Main Application Logic & Storefront
// Interactive UI, catalog filtering, load calculator, warranty checker, and modals

document.addEventListener('DOMContentLoaded', () => {
  // Initialize systems
  window.stockManager = new StockManagementSystem();
  window.cartSystem = new CartSystem();

  initHeroRotator();
  initScrollSpy();
  initVehicleFinder();
  initCatalogFilters();
  initLoadCalculator();
  initWarrantyChecker();
  initQuickViewModal();
  initGlobalSearch();
  initOutlets();
  renderProductsCatalog();
  renderBrandsGrid();
  renderCategoriesGrid();
});

// ==========================================================================
// 1. HERO TEXT ROTATOR
// ==========================================================================
function initHeroRotator() {
  const rotatorEl = document.getElementById('hero-rotator-text');
  if (!rotatorEl) return;

  const words = ['World', 'Future', 'Success', 'Every Journey', 'Home & Business'];
  let idx = 0;

  setInterval(() => {
    idx = (idx + 1) % words.length;
    rotatorEl.style.opacity = '0';
    rotatorEl.style.transform = 'translateY(8px)';

    setTimeout(() => {
      rotatorEl.textContent = words[idx];
      rotatorEl.style.opacity = '1';
      rotatorEl.style.transform = 'translateY(0)';
    }, 280);
  }, 2800);
}

// ==========================================================================
// 1B. NAVIGATION SCROLLSPY
// ==========================================================================
function initScrollSpy() {
  const sections = [
    { id: 'hero', href: '#' },
    { id: 'products-section', href: '#products-section' },
    { id: 'brands-section', href: '#brands-section' },
    { id: 'categories-section', href: '#categories-section' },
    { id: 'finder-section', href: '#finder-section' },
    { id: 'calculator-section', href: '#calculator-section' },
    { id: 'warranty-section', href: '#warranty-section' },
    { id: 'outlets-section', href: '#outlets-section' }
  ];

  const navItems = document.querySelectorAll('.nav-link-item');

  function updateActiveNav() {
    const scrollPos = window.scrollY + 180;
    let currentId = 'hero';

    for (let i = sections.length - 1; i >= 0; i--) {
      const el = document.getElementById(sections[i].id);
      if (el && el.offsetTop <= scrollPos) {
        currentId = sections[i].id;
        break;
      }
    }

    navItems.forEach(item => {
      const link = item.querySelector('a');
      if (!link) return;
      const href = link.getAttribute('href');
      const isMatch = (currentId === 'hero' && (href === '#' || href === '#hero')) || href === `#${currentId}`;
      item.classList.toggle('active', isMatch);
    });
  }

  window.addEventListener('scroll', updateActiveNav, { passive: true });
  updateActiveNav();
}

// ==========================================================================
// 2. VEHICLE BATTERY FINDER
// ==========================================================================
function initVehicleFinder() {
  const typeSelect = document.getElementById('finder-vehicle-type');
  const makeSelect = document.getElementById('finder-vehicle-make');
  const modelSelect = document.getElementById('finder-vehicle-model');
  const form = document.getElementById('vehicle-finder-form');

  if (!typeSelect || !makeSelect || !modelSelect || !form) return;

  function populateMakes() {
    const type = typeSelect.value;
    const db = type === 'cars' ? VEHICLE_DATABASE.cars : VEHICLE_DATABASE.bikes;
    makeSelect.innerHTML = '<option value="">Select Make / Manufacturer</option>' + 
      db.map(item => `<option value="${item.make}">${item.make}</option>`).join('');
    modelSelect.innerHTML = '<option value="">Select Model</option>';
    modelSelect.disabled = true;
  }

  function populateModels() {
    const type = typeSelect.value;
    const make = makeSelect.value;
    const db = type === 'cars' ? VEHICLE_DATABASE.cars : VEHICLE_DATABASE.bikes;
    const found = db.find(item => item.make === make);

    if (found && found.models.length > 0) {
      modelSelect.disabled = false;
      modelSelect.innerHTML = '<option value="">Select Model</option>' + 
        found.models.map(m => `<option value="${m}">${m}</option>`).join('');
    } else {
      modelSelect.innerHTML = '<option value="">Select Model</option>';
      modelSelect.disabled = true;
    }
  }

  typeSelect.addEventListener('change', populateMakes);
  makeSelect.addEventListener('change', populateModels);
  populateMakes();

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const type = typeSelect.value;
    const make = makeSelect.value;

    if (!make) {
      showToast('Please select your vehicle make', 'warning');
      return;
    }

    const db = type === 'cars' ? VEHICLE_DATABASE.cars : VEHICLE_DATABASE.bikes;
    const match = db.find(item => item.make === make);

    if (match && match.battery) {
      const battery = window.productsCatalog.find(p => p.id === match.battery);
      if (battery) {
        showToast(`Found recommended battery: ${battery.name}!`, 'success');
        openProductQuickView(battery.id);
        const productsSection = document.getElementById('products-section');
        if (productsSection) productsSection.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      const categoryToFilter = type === 'cars' ? 'car-battery' : 'automotive-battery';
      filterProductsByCategory(categoryToFilter);
      showToast(`Showing all batteries compatible with ${make}`, 'info');
      document.getElementById('products-section')?.scrollIntoView({ behavior: 'smooth' });
    }
  });
}

// ==========================================================================
// 3. CATALOG RENDERING & DYNAMIC FILTERS
// ==========================================================================
let currentCatalogFilter = {
  category: 'all',
  brand: 'all',
  search: '',
  onSale: false,
  inStockOnly: false,
  sort: 'featured',
  priceMax: 100000
};

function renderProductsCatalog() {
  const grid = document.getElementById('products-catalog-grid');
  const countEl = document.getElementById('catalog-products-count');
  if (!grid) return;

  const catalog = window.productsCatalog || [];

  let filtered = catalog.filter(product => {
    // Search
    if (currentCatalogFilter.search) {
      const q = currentCatalogFilter.search.toLowerCase();
      const match = product.name.toLowerCase().includes(q) || 
                    product.sku.toLowerCase().includes(q) || 
                    product.brand.toLowerCase().includes(q) ||
                    product.categories.some(c => c.includes(q));
      if (!match) return false;
    }

    // Category
    if (currentCatalogFilter.category !== 'all') {
      if (!product.categories.includes(currentCatalogFilter.category)) return false;
    }

    // Brand
    if (currentCatalogFilter.brand !== 'all') {
      if (product.brandSlug !== currentCatalogFilter.brand) return false;
    }

    // On sale
    if (currentCatalogFilter.onSale && (!product.originalPrice || product.originalPrice <= product.price)) {
      return false;
    }

    // In stock
    if (currentCatalogFilter.inStockOnly && product.stock <= 0) {
      return false;
    }

    // Price Max
    if (product.price > currentCatalogFilter.priceMax) {
      return false;
    }

    return true;
  });

  // Sorting
  if (currentCatalogFilter.sort === 'price-low') {
    filtered.sort((a, b) => a.price - b.price);
  } else if (currentCatalogFilter.sort === 'price-high') {
    filtered.sort((a, b) => b.price - a.price);
  } else if (currentCatalogFilter.sort === 'rating') {
    filtered.sort((a, b) => b.rating - a.rating);
  }

  if (countEl) countEl.textContent = `Showing ${filtered.length} of ${catalog.length} products`;

  if (filtered.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1 / -1; text-align:center; padding: 4rem 1rem; background: #fff; border-radius: var(--radius-lg); border: 1.5px dashed var(--color-border);">
        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="margin: 0 auto 1rem; color: #94A3B8;"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
        <h3 style="font-size:1.15rem; font-weight:700; color:#0F172A; margin-bottom:0.25rem;">No matching batteries or inverters found</h3>
        <p style="color:#64748B; font-size:0.9rem; margin-bottom:1rem;">Try relaxing your filters or resetting the price slider.</p>
        <button class="btn-primary-red" onclick="resetCatalogFilters()" style="margin:0 auto; padding:0.5rem 1.25rem; font-size:0.85rem;">Reset All Filters</button>
      </div>
    `;
    return;
  }

  grid.innerHTML = filtered.map(product => {
    let stockTag = '<span class="product-stock-tag in-stock">● In Stock</span>';
    if (product.stock === 0) {
      stockTag = '<span class="product-stock-tag out-stock">● Out of Stock</span>';
    } else if (product.stock <= product.minStock) {
      stockTag = `<span class="product-stock-tag low-stock">● Low: ${product.stock} Left</span>`;
    }

    const hasDiscount = product.originalPrice && product.originalPrice > product.price;

    return `
      <article class="product-card" id="card-${product.id}">
        <div class="product-thumb-box" onclick="openProductQuickView('${product.id}')" title="Click to view details for ${product.name}">
          <img src="${product.image}" alt="${product.name}" class="product-thumb-img" loading="lazy">
          ${hasDiscount ? `<span class="product-discount-badge">${product.discount || 'Special'}</span>` : ''}
          ${stockTag}
        </div>
        <div class="product-body">
          <span class="product-brand-badge" style="background:${product.brandColor}15; color:${product.brandColor}; border:1px solid ${product.brandColor}30;">
            ${product.brand}
          </span>
          <h3 class="product-title" onclick="openProductQuickView('${product.id}')" style="cursor:pointer;" title="${product.name}">
            ${product.name}
          </h3>
          <div class="product-specs-chip">
            ⚡ ${product.capacity || '12V'} | 🛡️ ${product.warranty ? product.warranty.split('(')[0] : 'Standard Warranty'}
          </div>
          <div class="product-pricing">
            <span class="price-current">NPR ${product.price.toLocaleString()}</span>
            ${hasDiscount ? `<span class="price-original">NPR ${product.originalPrice.toLocaleString()}</span>` : ''}
          </div>
          <div class="product-actions-row">
            <button class="btn-add-cart" onclick="window.cartSystem.addItem('${product.id}', 1, this)" ${product.stock <= 0 ? 'disabled style="opacity:0.5; cursor:not-allowed;"' : ''}>
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
              <span>${product.stock <= 0 ? 'Out of Stock' : 'Add to Cart'}</span>
            </button>
            <a href="https://wa.me/9779705997260?text=Hi%2C%20I%20am%20inquiring%20about%20${encodeURIComponent(product.name)}%20(SKU%3A%20${product.sku})%20priced%20at%20NPR%20${product.price}." target="_blank" rel="noopener noreferrer" class="btn-whatsapp-card" title="Chat on WhatsApp" aria-label="WhatsApp Inquiry">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
                <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91C2.13 13.66 2.59 15.36 3.45 16.86L2.05 22L7.3 20.62C8.75 21.41 10.38 21.83 12.04 21.83C17.5 21.83 21.95 17.38 21.95 11.92C21.95 9.27 20.92 6.78 19.05 4.91C17.18 3.03 14.69 2 12.04 2ZM12.05 20.15C10.57 20.15 9.12 19.75 7.85 19L7.55 18.82L4.43 19.64L5.26 16.6L5.06 16.29C4.24 14.98 3.81 13.47 3.81 11.91C3.81 7.37 7.5 3.69 12.05 3.69C14.25 3.69 16.31 4.55 17.87 6.11C19.42 7.66 20.28 9.72 20.28 11.92C20.27 16.46 16.59 20.15 12.05 20.15ZM16.57 14.37C16.32 14.25 15.1 13.65 14.87 13.56C14.64 13.48 14.48 13.44 14.31 13.68C14.15 13.93 13.66 14.5 13.51 14.67C13.37 14.83 13.22 14.85 12.97 14.73C12.72 14.6 11.93 14.34 10.99 13.51C10.26 12.86 9.77 12.05 9.62 11.8C9.48 11.55 9.61 11.42 9.73 11.3C9.84 11.19 9.98 11.01 10.1 10.87C10.23 10.73 10.27 10.62 10.35 10.46C10.44 10.29 10.39 10.15 10.33 10.03C10.27 9.9 9.77 8.68 9.57 8.18C9.37 7.69 9.17 7.76 9.02 7.75C8.88 7.74 8.71 7.74 8.55 7.74C8.38 7.74 8.12 7.8 7.89 8.05C7.67 8.3 7.03 8.89 7.03 10.1C7.03 11.31 7.91 12.47 8.03 12.63C8.16 12.8 9.76 15.26 12.21 16.32C12.79 16.57 13.25 16.72 13.6 16.83C14.19 17.02 14.72 16.99 15.15 16.93C15.63 16.86 16.62 16.33 16.83 15.75C17.03 15.16 17.03 14.66 16.97 14.56C16.91 14.45 16.82 14.49 16.57 14.37Z"/>
              </svg>
            </a>
            <button class="btn-quick-view" onclick="openProductQuickView('${product.id}')" title="View Full Details & Specs" aria-label="Quick View">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
            </button>
          </div>
        </div>
      </article>
    `;
  }).join('');
}

function initCatalogFilters() {
  const searchInput = document.getElementById('catalog-search-input');
  const sortSelect = document.getElementById('catalog-sort-select');
  const priceRange = document.getElementById('filter-price-slider');
  const priceDisplay = document.getElementById('price-slider-display');
  const saleCheckbox = document.getElementById('filter-sale-only');
  const inStockCheckbox = document.getElementById('filter-stock-only');

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      currentCatalogFilter.search = e.target.value;
      renderProductsCatalog();
    });
  }

  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      currentCatalogFilter.sort = e.target.value;
      renderProductsCatalog();
    });
  }

  if (priceRange && priceDisplay) {
    priceRange.addEventListener('input', (e) => {
      currentCatalogFilter.priceMax = Number(e.target.value);
      priceDisplay.textContent = `Up to NPR ${Number(e.target.value).toLocaleString()}`;
      renderProductsCatalog();
    });
  }

  if (saleCheckbox) {
    saleCheckbox.addEventListener('change', (e) => {
      currentCatalogFilter.onSale = e.target.checked;
      renderProductsCatalog();
    });
  }

  if (inStockCheckbox) {
    inStockCheckbox.addEventListener('change', (e) => {
      currentCatalogFilter.inStockOnly = e.target.checked;
      renderProductsCatalog();
    });
  }

  // Bind category checkbox group
  document.querySelectorAll('input[name="cat-filter-radio"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      currentCatalogFilter.category = e.target.value;
      renderProductsCatalog();
    });
  });

  // Bind brand checkbox group
  document.querySelectorAll('input[name="brand-filter-radio"]').forEach(radio => {
    radio.addEventListener('change', (e) => {
      currentCatalogFilter.brand = e.target.value;
      renderProductsCatalog();
    });
  });
}

function filterProductsByCategory(catId) {
  currentCatalogFilter.category = catId;
  const radio = document.querySelector(`input[name="cat-filter-radio"][value="${catId}"]`);
  if (radio) radio.checked = true;
  renderProductsCatalog();
}

function filterProductsByBrand(brandSlug) {
  currentCatalogFilter.brand = brandSlug;
  const radio = document.querySelector(`input[name="brand-filter-radio"][value="${brandSlug}"]`);
  if (radio) radio.checked = true;
  renderProductsCatalog();
  document.getElementById('products-section')?.scrollIntoView({ behavior: 'smooth' });
}

function resetCatalogFilters() {
  currentCatalogFilter = {
    category: 'all',
    brand: 'all',
    search: '',
    onSale: false,
    inStockOnly: false,
    sort: 'featured',
    priceMax: 100000
  };

  const searchInput = document.getElementById('catalog-search-input');
  if (searchInput) searchInput.value = '';

  const sortSelect = document.getElementById('catalog-sort-select');
  if (sortSelect) sortSelect.value = 'featured';

  const catAllRadio = document.querySelector('input[name="cat-filter-radio"][value="all"]');
  if (catAllRadio) catAllRadio.checked = true;

  const brandAllRadio = document.querySelector('input[name="brand-filter-radio"][value="all"]');
  if (brandAllRadio) brandAllRadio.checked = true;

  const saleCheckbox = document.getElementById('filter-sale-only');
  if (saleCheckbox) saleCheckbox.checked = false;

  const inStockCheckbox = document.getElementById('filter-stock-only');
  if (inStockCheckbox) inStockCheckbox.checked = false;

  const priceRange = document.getElementById('filter-price-slider');
  const priceDisplay = document.getElementById('price-slider-display');
  if (priceRange) priceRange.value = 100000;
  if (priceDisplay) priceDisplay.textContent = 'Up to NPR 100,000';

  renderProductsCatalog();
}

// ==========================================================================
// 4. BRANDS & CATEGORIES RENDERING (BIGGER BRANDS LOGOS)
// ==========================================================================
function renderBrandsGrid() {
  const container = document.getElementById('brands-grid-container');
  if (!container) return;

  container.innerHTML = BRANDS_LIST.map(brand => `
    <div class="brand-card-item ${brand.featured ? 'featured' : ''}" onclick="filterProductsByBrand('${brand.slug}')">
      <img src="${brand.logo}" alt="${brand.name}" class="brand-card-logo" loading="lazy">
      <div class="brand-card-name">${brand.name}</div>
      <div class="brand-card-desc">${brand.desc}</div>
    </div>
  `).join('');
}

function renderCategoriesGrid() {
  const container = document.getElementById('categories-grid-container');
  if (!container) return;

  container.innerHTML = CATEGORIES_LIST.map(cat => `
    <div class="category-card" onclick="filterProductsByCategory('${cat.id}'); document.getElementById('products-section')?.scrollIntoView({behavior:'smooth'});">
      <div class="category-card-icon">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="16" height="10" x="2" y="7" rx="2" ry="2"/><line x1="22" x2="22" y1="11" y2="13"/></svg>
      </div>
      <div class="category-card-info">
        <h3>${cat.name}</h3>
        <p>${cat.desc}</p>
        <div class="category-card-arrow">View Products →</div>
      </div>
    </div>
  `).join('');
}

// ==========================================================================
// 5. PRODUCT QUICK VIEW / DETAILS MODAL & INTERACTIVE ZOOM & GALLERY
// ==========================================================================
function initQuickViewModal() {
  const overlay = document.getElementById('quickview-modal-overlay');
  if (overlay) {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeQuickViewModal();
    });
  }
}

function openProductQuickView(productId) {
  const product = window.productsCatalog ? window.productsCatalog.find(p => p.id === productId) : null;
  if (!product) return;

  const contentBox = document.getElementById('quickview-modal-body');
  if (!contentBox) return;

  // Build gallery images: use product.images if available, else primary plus variants
  let galleryImages = [];
  if (product.images && Array.isArray(product.images) && product.images.length > 0) {
    galleryImages = [...product.images];
  } else {
    galleryImages = [product.image];
    if (product.categories.includes('inverter-battery')) {
      galleryImages.push('assets/images/exide-imtt2000.png', 'assets/images/sf-150ah.png', 'assets/images/livfast-1954.png');
    } else if (product.categories.includes('car-battery') || product.categories.includes('automotive-battery')) {
      galleryImages.push('assets/images/exide-matrix.png', 'assets/images/exide-xplore.png', 'assets/images/sf-150ah.png');
    } else if (product.categories.includes('inverter') || product.categories.includes('ups')) {
      galleryImages.push('assets/images/livfast-1845.webp', 'assets/images/smarten-everon.png', 'assets/images/genus-maxilion.webp');
    } else if (product.categories.includes('solar-hybrid-pcu')) {
      galleryImages.push('assets/images/eastman-solar.png', 'assets/images/livfast-reno.png', 'assets/images/smarten-lithium.png');
    } else {
      galleryImages.push('assets/images/geon-lithium.png', 'assets/images/livfast-1954.png');
    }
  }

  const specsList = Object.entries(product.specs || {})
    .filter(([k, v]) => {
      if (v === null || v === undefined) return false;
      const str = String(v).trim();
      return str !== '' && str !== '0' && str !== '0.0' && str !== '0 Ah' && str !== '0 V' && str !== '0W' && str !== '0VA';
    })
    .map(([k, v]) => `
    <tr>
      <th style="background:#F8FAFC; padding:0.65rem 0.9rem; text-align:left; font-size:0.82rem; width:36%; border-bottom:1px solid #E2E8F0; color:#334155;">${k}</th>
      <td style="padding:0.65rem 0.9rem; font-size:0.85rem; border-bottom:1px solid #E2E8F0; color:#0F172A; font-weight:600;">${v}</td>
    </tr>
  `).join('');

  // Related products
  const related = (window.productsCatalog || [])
    .filter(p => p.id !== product.id && (p.brandSlug === product.brandSlug || p.categories.some(c => product.categories.includes(c))))
    .slice(0, 3);

  contentBox.innerHTML = `
    <div class="quickview-scroll-wrapper">
      <div class="quickview-grid">
        <!-- Left: Image Gallery with Interactive Zoom -->
        <div>
          <div class="quickview-zoom-container" id="quickview-zoom-box">
            <img src="${product.image}" alt="${product.name}" class="quickview-img" id="quickview-main-image">
          </div>

          <!-- Multiple Thumbnails (Hover to Auto-Display as Main) -->
          <div class="quickview-gallery-strip">
            ${galleryImages.map((imgSrc, idx) => `
              <div class="quickview-thumb-item ${idx === 0 ? 'active' : ''}" onmouseenter="switchQuickViewImage('${imgSrc}', this)" onclick="switchQuickViewImage('${imgSrc}', this)">
                <img src="${imgSrc}" alt="${product.name} view ${idx + 1}">
              </div>
            `).join('')}
          </div>
          <p style="text-align:center; font-size:0.75rem; color:#64748B; margin-top:0.4rem;">
            Hover over any thumbnail to instantly preview
          </p>
        </div>

        <!-- Right: Product Info, Actions & Buying -->
        <div>
          <div style="display:flex; align-items:center; gap:0.5rem; margin-bottom:0.5rem; flex-wrap:wrap;">
            <span class="product-brand-badge" style="background:${product.brandColor}15; color:${product.brandColor}; border:1px solid ${product.brandColor}30;">
              AET Official Partner • ${product.brand} Genuine
            </span>
            <span style="font-size:0.75rem; font-weight:700; color:var(--color-success); background:var(--color-success-bg); padding:2px 8px; border-radius:4px;">
              ✓ 100% Genuine Stamped Warranty
            </span>
          </div>

          <h2 style="font-family:var(--font-heading); font-size:1.65rem; font-weight:800; line-height:1.2; color:#0F172A; margin-bottom:0.5rem;">
            ${product.name}
          </h2>

          <div style="font-family:monospace; font-size:0.85rem; color:#64748B; margin-bottom:1rem; display:flex; gap:1rem; flex-wrap:wrap;">
            <span>SKU: <strong>${product.sku}</strong></span>
            <span>Stock: <strong style="color:${product.stock > 0 ? 'var(--color-success)' : 'var(--color-danger)'};">${product.stock > 0 ? product.stock + ' units ready in store' : 'Out of stock'}</strong></span>
            <span>Rating: <strong style="color:#D97706;">★ ${product.rating || 4.9} (${product.reviewsCount || 84} reviews)</strong></span>
          </div>

          <div style="display:flex; align-items:baseline; gap:0.75rem; margin-bottom:1.25rem;">
            <span style="font-family:var(--font-heading); font-size:1.85rem; font-weight:800; color:var(--color-exide-red);">
              NPR ${product.price.toLocaleString()}
            </span>
            ${product.originalPrice && product.originalPrice > product.price ? `
              <span style="font-size:1.05rem; color:#94A3B8; text-decoration:line-through;">
                NPR ${product.originalPrice.toLocaleString()}
              </span>
              <span class="product-discount-badge" style="position:static;">
                ${product.discount}
              </span>
            ` : ''}
          </div>

          <!-- Short Description -->
          <div style="background:#F8FAFC; border-left:4px solid var(--color-exide-blue); padding:0.75rem 1rem; border-radius:0 6px 6px 0; font-size:0.88rem; color:#334155; margin-bottom:1.25rem; line-height:1.5;">
            ${product.shortDesc || product.description}
          </div>

          <!-- Tagged Compatible Vehicles (for Automotive / Car Batteries) -->
          ${((product.compatibleVehicles && product.compatibleVehicles.length) || (product.specs && product.specs['Compatible Vehicles'])) ? `
            <div style="background:#EFF6FF; border:1px solid #BFDBFE; border-radius:8px; padding:0.75rem 1rem; margin-bottom:1.25rem;">
              <div style="font-size:0.8rem; font-weight:800; color:#1D4ED8; margin-bottom:0.4rem; display:flex; align-items:center; gap:0.4rem;">
                🚗 Compatible Vehicles & Models:
              </div>
              <div style="display:flex; flex-wrap:wrap; gap:0.4rem;">
                ${(product.compatibleVehicles || (product.specs['Compatible Vehicles'] || '').split(',').map(s=>s.trim())).filter(Boolean).map(veh => `
                  <span style="background:#FFFFFF; color:#1E40AF; border:1px solid #93C5FD; font-size:0.75rem; font-weight:700; padding:2px 8px; border-radius:4px; box-shadow:0 1px 2px rgba(0,0,0,0.05);">${veh}</span>
                `).join('')}
              </div>
            </div>
          ` : ''}

          <!-- Actions Row: Animated Add to Cart & Aligned WhatsApp Button -->
          <div class="quickview-actions-group">
            <button class="btn-primary-red btn-quickview-cart" onclick="window.cartSystem.addItem('${product.id}', 1, this)" ${product.stock <= 0 ? 'disabled style="opacity:0.5;"' : ''}>
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
              <span>Add to Cart</span>
            </button>
            <a href="https://wa.me/9779705997260?text=Hi%20Exide%20Battery%20Wholesale%2C%20I%20am%20interested%20in%20${encodeURIComponent(product.name)}%20(SKU%3A%20${product.sku})%20priced%20at%20NPR%20${product.price}." target="_blank" rel="noopener noreferrer" class="btn-whatsapp-aligned">
              <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor">
                <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91C2.13 13.66 2.59 15.36 3.45 16.86L2.05 22L7.3 20.62C8.75 21.41 10.38 21.83 12.04 21.83C17.5 21.83 21.95 17.38 21.95 11.92C21.95 9.27 20.92 6.78 19.05 4.91C17.18 3.03 14.69 2 12.04 2ZM12.05 20.15C10.57 20.15 9.12 19.75 7.85 19L7.55 18.82L4.43 19.64L5.26 16.6L5.06 16.29C4.24 14.98 3.81 13.47 3.81 11.91C3.81 7.37 7.5 3.69 12.05 3.69C14.25 3.69 16.31 4.55 17.87 6.11C19.42 7.66 20.28 9.72 20.28 11.92C20.27 16.46 16.59 20.15 12.05 20.15ZM16.57 14.37C16.32 14.25 15.1 13.65 14.87 13.56C14.64 13.48 14.48 13.44 14.31 13.68C14.15 13.93 13.66 14.5 13.51 14.67C13.37 14.83 13.22 14.85 12.97 14.73C12.72 14.6 11.93 14.34 10.99 13.51C10.26 12.86 9.77 12.05 9.62 11.8C9.48 11.55 9.61 11.42 9.73 11.3C9.84 11.19 9.98 11.01 10.1 10.87C10.23 10.73 10.27 10.62 10.35 10.46C10.44 10.29 10.39 10.15 10.33 10.03C10.27 9.9 9.77 8.68 9.57 8.18C9.37 7.69 9.17 7.76 9.02 7.75C8.88 7.74 8.71 7.74 8.55 7.74C8.38 7.74 8.12 7.8 7.89 8.05C7.67 8.3 7.03 8.89 7.03 10.1C7.03 11.31 7.91 12.47 8.03 12.63C8.16 12.8 9.76 15.26 12.21 16.32C12.79 16.57 13.25 16.72 13.6 16.83C14.19 17.02 14.72 16.99 15.15 16.93C15.63 16.86 16.62 16.33 16.83 15.75C17.03 15.16 17.03 14.66 16.97 14.56C16.91 14.45 16.82 14.49 16.57 14.37Z"/>
              </svg>
              <span>WhatsApp Inquiry</span>
            </a>
          </div>

          <!-- Doorstep Service Highlights -->
          <div class="product-perks-strip">
            <div class="perk-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
              <span>Free Delivery & Terminal Fitting</span>
            </div>
            <div class="perk-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
              <span>Old Scrap Battery Cash Rebate</span>
            </div>
            <div class="perk-item">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
              <span>Doorstep Claim at Any Nepal Outlet</span>
            </div>
          </div>
        </div>
      </div>

      <!-- Detailed Description & Highlights -->
      <div style="margin-top:2rem; padding-top:1.5rem; border-top:1px solid #E2E8F0;">
        <h3 style="font-size:1.15rem; font-weight:800; color:#0F172A; margin-bottom:0.75rem;">Product Overview & In-Depth Details</h3>
        <div class="product-description-body" style="font-size:0.92rem; color:#475569; line-height:1.7; margin-bottom:1.25rem;">
          ${product.description}
        </div>

        ${product.features && product.features.length ? `
          <h4 style="font-size:0.95rem; font-weight:800; color:#0F172A; margin-bottom:0.5rem;">Key Engineering Advantages:</h4>
          <ul style="list-style:disc; margin-left:1.5rem; color:#475569; font-size:0.9rem; line-height:1.7; margin-bottom:1.5rem;">
            ${product.features.map(f => `<li>${f}</li>`).join('')}
          </ul>
        ` : ''}

        <!-- Technical Specifications Table -->
        <h3 style="font-size:1.15rem; font-weight:800; color:#0F172A; margin-bottom:0.75rem;">Official Technical Specifications</h3>
        <table class="specs-full-table">
          <tbody>${specsList}</tbody>
        </table>
      </div>

      <!-- Related Products Section (Fully Scrollable & Interactive) -->
      ${related.length > 0 ? `
        <div class="related-products-section">
          <div class="related-header">
            <h3>You May Also Need / Related Power Solutions</h3>
            <span style="font-size:0.85rem; color:#64748B;">Compatible with your setup</span>
          </div>
          <div class="related-products-grid">
            ${related.map(r => `
              <div class="related-card" onclick="openProductQuickView('${r.id}')">
                <img src="${r.image}" alt="${r.name}" class="related-thumb">
                <div class="related-body">
                  <span class="related-brand">${r.brand}</span>
                  <h4 class="related-title" title="${r.name}">${r.name}</h4>
                  <div class="related-price">NPR ${r.price.toLocaleString()}</div>
                  <button class="btn-primary-red" style="height:32px; font-size:0.75rem; width:100%; margin-top:0.4rem;" onclick="event.stopPropagation(); window.cartSystem.addItem('${r.id}', 1, this);">
                    + Add to Cart
                  </button>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      ` : ''}
    </div>
  `;

  initImageZoom();
  document.getElementById('quickview-modal-overlay').classList.add('open');
}

function switchQuickViewImage(src, thumbEl) {
  const mainImg = document.getElementById('quickview-main-image');
  if (mainImg) {
    mainImg.style.opacity = '0.4';
    setTimeout(() => {
      mainImg.src = src;
      mainImg.style.opacity = '1';
    }, 120);
  }
  document.querySelectorAll('.quickview-thumb-item').forEach(t => t.classList.remove('active'));
  if (thumbEl) thumbEl.classList.add('active');
}

function initImageZoom() {
  const box = document.getElementById('quickview-zoom-box');
  const img = document.getElementById('quickview-main-image');
  if (!box || !img) return;

  box.addEventListener('mousemove', (e) => {
    const rect = box.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    img.style.transformOrigin = `${x}% ${y}%`;
    img.style.transform = 'scale(1.45)';
  });

  box.addEventListener('mouseleave', () => {
    img.style.transformOrigin = 'center center';
    img.style.transform = 'scale(1)';
  });
}

function closeQuickViewModal() {
  document.getElementById('quickview-modal-overlay').classList.remove('open');
}

// ==========================================================================
// 6. INVERTER & BATTERY LOAD CALCULATOR (NEPAL POWER SIZING)
// ==========================================================================
const APPLIANCES_CONFIG = [
  { id: 'app-led', name: 'LED Lights (15W)', watt: 15, count: 6 },
  { id: 'app-fan', name: 'Ceiling Fans (75W)', watt: 75, count: 3 },
  { id: 'app-tv', name: 'LED TV (100W)', watt: 100, count: 1 },
  { id: 'app-router', name: 'Wi-Fi Router (15W)', watt: 15, count: 1 },
  { id: 'app-pc', name: 'Computer / Laptop (120W)', watt: 120, count: 1 },
  { id: 'app-fridge', name: 'Refrigerator (250W)', watt: 250, count: 0 },
  { id: 'app-pump', name: 'Water Pump (750W / 1HP)', watt: 750, count: 0 },
  { id: 'app-cooler', name: 'Room Cooler / Mixer (180W)', watt: 180, count: 0 }
];

let selectedBackupHours = 4;
let selectedSystemType = 'inverter'; // 'inverter' | 'solar' | 'both'
let calcSelectedItems = {
  includeBattery: true,
  includeInverter: true
};

function initLoadCalculator() {
  const container = document.getElementById('calc-appliances-container');
  if (!container) return;

  container.innerHTML = APPLIANCES_CONFIG.map(app => `
    <div class="calc-appliance-item">
      <div class="appliance-info">
        <span class="appliance-name">${app.name}</span>
        <span class="appliance-watt">${app.watt} Watts each</span>
      </div>
      <div class="qty-control">
        <button class="qty-btn" type="button" onclick="updateCalcAppliance('${app.id}', -1)">-</button>
        <input type="number" id="qty-${app.id}" class="calc-qty-input" value="${app.count}" min="0" max="99" oninput="setCalcApplianceQty('${app.id}', this.value)" onchange="setCalcApplianceQty('${app.id}', this.value)">
        <button class="qty-btn" type="button" onclick="updateCalcAppliance('${app.id}', 1)">+</button>
      </div>
    </div>
  `).join('');

  // Quick buttons (1 to 4 hours)
  document.querySelectorAll('.btn-hour-choice').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.btn-hour-choice').forEach(b => b.classList.remove('active'));
      e.target.classList.add('active');
      selectedBackupHours = parseInt(e.target.dataset.hours, 10);
      const dropdown = document.getElementById('calc-backup-hours-dropdown');
      if (dropdown) dropdown.value = selectedBackupHours;
      recalculatePower();
    });
  });

  // Dropdown menu for backup hours
  const hoursDropdown = document.getElementById('calc-backup-hours-dropdown');
  if (hoursDropdown) {
    hoursDropdown.addEventListener('change', (e) => {
      selectedBackupHours = parseInt(e.target.value, 10);
      document.querySelectorAll('.btn-hour-choice').forEach(b => {
        b.classList.toggle('active', parseInt(b.dataset.hours, 10) === selectedBackupHours);
      });
      recalculatePower();
    });
  }

  // Energy source / system type selector buttons
  document.querySelectorAll('.btn-sys-type').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.btn-sys-type').forEach(b => b.classList.remove('active'));
      const targetBtn = e.target.closest('.btn-sys-type');
      targetBtn.classList.add('active');
      selectedSystemType = targetBtn.dataset.type;
      recalculatePower();
    });
  });

  recalculatePower();
}

function updateCalcAppliance(appId, delta) {
  const app = APPLIANCES_CONFIG.find(a => a.id === appId);
  if (!app) return;

  app.count = Math.max(0, app.count + delta);
  const input = document.getElementById(`qty-${app.id}`);
  if (input) input.value = app.count;

  recalculatePower();
}

function setCalcApplianceQty(appId, val) {
  const app = APPLIANCES_CONFIG.find(a => a.id === appId);
  if (!app) return;

  const parsed = parseInt(val, 10);
  app.count = isNaN(parsed) || parsed < 0 ? 0 : parsed;
  recalculatePower();
}

function recalculatePower() {
  const totalWatts = APPLIANCES_CONFIG.reduce((sum, a) => sum + (a.watt * a.count), 0);

  // Inverter Power Factor: 0.8 with 25% surge safety margin
  const recommendedVA = Math.round((totalWatts / 0.8) * 1.25);

  // Battery Energy needed Wh = (Watts * Hours) / 0.85 efficiency
  const energyWh = Math.round((totalWatts * selectedBackupHours) / 0.85);

  // Determine system DC Voltage (12V, 24V or 48V)
  let systemVoltage = 12;
  let batteryQuantity = 1;

  if (recommendedVA > 2200) {
    systemVoltage = 48;
    batteryQuantity = 4;
  } else if (recommendedVA > 1150) {
    systemVoltage = 24;
    batteryQuantity = 2;
  } else {
    systemVoltage = 12;
    batteryQuantity = 1;
  }

  // Required Ah per battery at that system voltage
  const requiredAhPerBattery = Math.round(energyWh / (systemVoltage * (systemVoltage === 12 ? 1 : (systemVoltage === 24 ? 1 : 1))));
  const totalAh12VEquiv = Math.round(energyWh / 12);

  // Determine Battery Specification
  let batteryModelName = "Exide 150 Ah Invamaster Tubular Battery (IMTT1500)";
  let batteryAmpereRating = "150 Ah";
  let batteryPrice = 34000;
  let targetBatteryId = "exide-battery-150-invamaster";

  if (totalAh12VEquiv > 220 || requiredAhPerBattery > 160) {
    batteryModelName = "Exide 200 Ah Invamaster Tall Tubular Battery (IMTT2000)";
    batteryAmpereRating = "200 Ah";
    batteryPrice = 44499;
    targetBatteryId = "exide-200ah-invamaster-battery";
  } else if (totalAh12VEquiv <= 90 && recommendedVA <= 850 && batteryQuantity === 1) {
    batteryModelName = "Exide Matrix 12V 80Ah Heavy-Duty Battery";
    batteryAmpereRating = "80 Ah";
    batteryPrice = 19800;
    targetBatteryId = "exide-matrix-car-battery";
  }

  // Determine Inverter / UPS / Solar Model based on Application
  let inverterModelName = "";
  let inverterPrice = 18500;
  let targetInverterId = "livfast-1175-inverter";

  if (selectedSystemType === 'solar') {
    if (systemVoltage >= 24) {
      inverterModelName = "Eastman 1500VA Solar Hybrid MPPT PCU (24V)";
      inverterPrice = 34000;
      targetInverterId = "eastman-solar-hybrid-pcu";
    } else {
      inverterModelName = "Smarten Superpower 1100VA MPPT Solar PCU (12V)";
      inverterPrice = 23500;
      targetInverterId = "smarten-superpower-pcu";
    }
  } else if (selectedSystemType === 'both') {
    if (systemVoltage >= 24) {
      inverterModelName = "Smarten Saver 2500VA Heavy-Duty Solar & Grid Dual PCU (24V)";
      inverterPrice = 44000;
      targetInverterId = "smarten-saver-dual-pcu";
    } else {
      inverterModelName = "Livfast 1175 Pure Sinewave Dual Solar-Grid Inverter (12V)";
      inverterPrice = 22000;
      targetInverterId = "livfast-1175-inverter";
    }
  } else {
    // Normal Inverter / Home UPS
    if (systemVoltage >= 24) {
      inverterModelName = "Smarten 1500VA Pure Sinewave Inverter (24V System)";
      inverterPrice = 26500;
      targetInverterId = "smarten-lithium-inverter";
    } else {
      inverterModelName = "Livfast 1175 Pure Sinewave Inverter (1050VA / 12V)";
      inverterPrice = 18500;
      targetInverterId = "livfast-1175-inverter";
    }
  }

  // Update UI Elements
  const wattEl = document.getElementById('calc-total-watts');
  const vaEl = document.getElementById('calc-recommended-va');
  const ahEl = document.getElementById('calc-recommended-ah');
  const pkgContainer = document.getElementById('calc-package-breakdown');

  if (wattEl) wattEl.textContent = `${totalWatts} W`;
  if (vaEl) vaEl.textContent = `${Math.max(900, recommendedVA)} VA (${systemVoltage}V System)`;
  if (ahEl) ahEl.textContent = `${batteryQuantity}x ${batteryAmpereRating} (${totalAh12VEquiv} Ah eq.)`;

  if (pkgContainer) {
    const totalBatteryCost = batteryPrice * batteryQuantity;
    const totalPkgPrice = (calcSelectedItems.includeBattery ? totalBatteryCost : 0) + (calcSelectedItems.includeInverter ? inverterPrice : 0);

    pkgContainer.innerHTML = `
      <div class="pkg-config-badge">
        <span>⚡ System Architecture: <strong>${systemVoltage}V DC Bus</strong></span>
        <span>🕒 Target Backup: <strong>${selectedBackupHours} Hours</strong></span>
      </div>

      <div class="pkg-paired-list">
        <!-- Battery Option -->
        <label class="pkg-check-row">
          <input type="checkbox" id="calc-check-batt" ${calcSelectedItems.includeBattery ? 'checked' : ''} onchange="toggleCalcItem('includeBattery', this.checked)">
          <div class="pkg-item-desc">
            <span class="pkg-item-type">🔋 Recommended Battery:</span>
            <strong>${batteryQuantity}x ${batteryModelName}</strong>
            <small style="color:#64748B; display:block;">Capacity: ${batteryAmpereRating} each | 36 Months Official Warranty</small>
          </div>
          <div class="pkg-item-price">
            NPR ${totalBatteryCost.toLocaleString()}
          </div>
        </label>

        <!-- Inverter Option -->
        <label class="pkg-check-row">
          <input type="checkbox" id="calc-check-inv" ${calcSelectedItems.includeInverter ? 'checked' : ''} onchange="toggleCalcItem('includeInverter', this.checked)">
          <div class="pkg-item-desc">
            <span class="pkg-item-type">🔌 Paired Inverter / PCU:</span>
            <strong>1x ${inverterModelName}</strong>
            <small style="color:#64748B; display:block;">Output: ${Math.max(900, recommendedVA)} VA Rating | Pure Sine Wave</small>
          </div>
          <div class="pkg-item-price">
            NPR ${inverterPrice.toLocaleString()}
          </div>
        </label>
      </div>

      <div class="pkg-summary-bar">
        <div>
          <span style="font-size:0.8rem; color:#64748B; display:block;">Estimated Package Price:</span>
          <strong style="font-size:1.3rem; color:var(--color-exide-red);">NPR ${totalPkgPrice.toLocaleString()}</strong>
        </div>
        <button class="btn-primary-red btn-calc-add" id="calc-add-pkg-btn" onclick="addCalculatedPackageToCart('${targetBatteryId}', ${batteryQuantity}, '${targetInverterId}', this)">
          <span>Add Selected to Cart</span>
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
        </button>
      </div>
    `;
  }
}

function toggleCalcItem(itemKey, isChecked) {
  calcSelectedItems[itemKey] = isChecked;
  recalculatePower();
}

function addCalculatedPackageToCart(batteryId, batteryQty, inverterId, btnEl) {
  if (!calcSelectedItems.includeBattery && !calcSelectedItems.includeInverter) {
    showToast('Please check at least one component (Battery or Inverter)', 'warning');
    return;
  }

  if (calcSelectedItems.includeBattery) {
    window.cartSystem.addItem(batteryId, batteryQty);
  }

  if (calcSelectedItems.includeInverter) {
    window.cartSystem.addItem(inverterId, 1);
  }

  if (btnEl) {
    animateAddToCartButton(btnEl);
  }

  showToast('Recommended power system added to cart!', 'success');
}

// ==========================================================================
// 7. WARRANTY VERIFICATION TOOL
// ==========================================================================
function initWarrantyChecker() {
  const form = document.getElementById('warranty-checker-form');
  const resultBox = document.getElementById('warranty-result-box');
  if (!form || !resultBox) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const serial = document.getElementById('warranty-serial-input').value.trim().toUpperCase();
    if (!serial) {
      showToast('Please enter your battery serial number', 'warning');
      return;
    }

    let foundProduct = null;
    (window.productsCatalog || []).forEach(p => {
      if (p.serialNumbers && p.serialNumbers.some(s => s.toUpperCase() === serial)) {
        foundProduct = p;
      }
    });

    if (foundProduct || serial.startsWith('EX-') || serial.startsWith('SN-')) {
      const prodName = foundProduct ? foundProduct.name : 'Exide Genuine Tubular Power Battery';
      const warrantyPeriod = foundProduct ? foundProduct.warranty : '36 Months Official Warranty';

      resultBox.style.display = 'block';
      resultBox.innerHTML = `
        <div style="background:var(--color-success-bg); border:1.5px solid var(--color-success); border-radius:var(--radius-md); padding:1.25rem;">
          <div style="display:flex; align-items:center; gap:0.5rem; color:var(--color-success); font-weight:800; font-size:1.1rem; margin-bottom:0.5rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
            100% Genuine Authorized Battery Verified
          </div>
          <div style="font-size:0.9rem; color:#0F172A; margin-bottom:0.25rem;">
            Product: <strong>${prodName}</strong>
          </div>
          <div style="font-size:0.85rem; color:#475569;">
            Serial Number: <code style="font-weight:700;">${serial}</code>
          </div>
          <div style="font-size:0.85rem; color:#475569;">
            Warranty Coverage: <strong style="color:var(--color-exide-blue);">${warrantyPeriod}</strong>
          </div>
          <div style="font-size:0.8rem; color:#10B981; margin-top:0.5rem; font-weight:600;">
            ✓ Eligible for free doorstep service & replacement claim at any Exide Battery Wholesale outlet (Hotline: +9779705997260).
          </div>
        </div>
      `;
      showToast('Serial verified successfully!', 'success');
    } else {
      resultBox.style.display = 'block';
      resultBox.innerHTML = `
        <div style="background:var(--color-danger-bg); border:1.5px solid var(--color-danger); border-radius:var(--radius-md); padding:1.25rem;">
          <div style="color:var(--color-danger); font-weight:800; font-size:1rem; margin-bottom:0.25rem;">
            Serial Number Not Found in Live Records
          </div>
          <p style="font-size:0.85rem; color:#475569;">
            If you purchased this battery from an authorized sub-dealer, please contact our Nepal hotline at <strong>+9779705997260</strong> with your purchase receipt.
          </p>
        </div>
      `;
    }
  });
}

// ==========================================================================
// 8. STORE OUTLETS
// ==========================================================================
function initOutlets() {
  const container = document.getElementById('outlets-grid-container');
  if (!container || !NEPAL_LOCATIONS) return;

  container.innerHTML = NEPAL_LOCATIONS.outlets.map(o => `
    <div class="outlet-card">
      <div class="outlet-city">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color:var(--color-exide-red);"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
        ${o.city}
      </div>
      <div class="outlet-address">${o.address}</div>
      <div style="font-size:0.8rem; color:#64748B; margin-bottom:0.75rem;">🕒 ${o.time}</div>
      <a href="tel:${o.phone.replace(/[^0-9+]/g, '')}" class="outlet-contact-link">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
        ${o.phone}
      </a>
    </div>
  `).join('');
}

// ==========================================================================
// 9. GLOBAL SEARCH
// ==========================================================================
function initGlobalSearch() {
  const headerSearchInput = document.getElementById('global-search-input');
  if (!headerSearchInput) return;

  headerSearchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const val = headerSearchInput.value.trim();
      currentCatalogFilter.search = val;
      const catalogSearchInput = document.getElementById('catalog-search-input');
      if (catalogSearchInput) catalogSearchInput.value = val;
      renderProductsCatalog();
      document.getElementById('products-section')?.scrollIntoView({ behavior: 'smooth' });
    }
  });
}
